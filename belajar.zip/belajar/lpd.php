<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="Content-Style-Type" content="text/css" />
        <meta name="generator" content="Aspose.Words for .NET 22.1.0" />
        <title>LAPORAN HASIL PERJALANAN DINAS</title>
        <style type="text/css">
        body { line-height:108%; font-family:Calibri; font-size:11pt }
        p { margin:0pt 0pt 8pt }
        li, table { margin-top:0pt; margin-bottom:8pt }
        .ListParagraph { margin-left:36pt; margin-bottom:8pt; line-height:108%; font-size:11pt }
        span.Hyperlink { text-decoration:underline; color:#0563c1 }
        span.UnresolvedMention { color:#605e5c; background-color:#e1dfdd }
        .TableGrid {  }</style>
        </head>
        <body>

        <?php
        $nama = @$_POST['nama'];
        $berangkat = @$_POST['berangkat'];
        $tujuan = @$_POST['tujuan'];
        $hasil1 = @$_POST['hasil1'];
        $hasil2 = @$_POST['hasil2'];
        $hasil3 = @$_POST['hasil3'];
        $hasil4 = @$_POST['hasil4'];
        $tgl_kembali = @$_POST['tgl_kembali'];
        $foto1 = @$_FILES["foto1"]["name"];
        $tmp_name = @$_FILES["foto1"]["tmp_name"];
		move_uploaded_file($tmp_name, "images/".$foto1);
        $foto2 = @$_FILES["foto2"]["name"];
        $tmp_name = @$_FILES["foto2"]["tmp_name"];
		move_uploaded_file($tmp_name, "images/".$foto2);
        ?>
            <div>
                <table cellspacing="0" cellpadding="0" class="TableGrid" style="margin-bottom:0pt; border-collapse:collapse">
                <tr style="height:70.55pt">
                <td style="width:59.85pt; border-bottom-style:solid; border-bottom-width:4.5pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top; -aw-border-bottom:3pt thin-thick-small-gap">
                <p style="margin-bottom:0pt; font-size:11pt"><img src="images/Aspose.Words.05055d3e-3b48-405f-ac62-d07102973d18.001.png" width="79" height="86" alt="" style="-aw-left-pos:0pt; -aw-rel-hpos:column; -aw-rel-vpos:paragraph; -aw-top-pos:0pt; -aw-wrap-type:inline" /></p>
            </td><td style="width:322.1pt; border-bottom-style:solid; border-bottom-width:4.5pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top; -aw-border-bottom:3pt thin-thick-small-gap"><p style="margin-bottom:0pt; text-align:center; font-size:11pt"><span style="font-weight:bold">PEMERINTAH PROVINSI SULAWESI SELATAN</span></p><p style="margin-bottom:0pt; text-align:center; font-size:11pt"><span style="font-weight:bold">DINAS PENDIDIKAN</span></p><p style="margin-bottom:0pt; text-align:center; font-size:11pt"><span style="font-weight:bold">SMK NEGERI 9 BULUKUMBA</span></p><p style="margin-bottom:0pt; text-align:center; font-size:9pt"><span style="font-style:italic">Alamat : Jln. Pendidikan No. 57 KalumpangKec. Bontotiro Kode Pos 92572</span></p><p style="margin-bottom:0pt; text-align:center; font-size:11pt"><span style="font-size:9pt; font-style:italic">Email : </span><a href="mailto:smkn9bulukumba@yahoo.com" style="text-decoration:none"><span class="Hyperlink" style="font-size:9pt; font-style:italic">smkn9bulukumba@yahoo.com</span></a><span style="font-size:9pt; font-style:italic"> Web.https://smkn9bulukumba.sch.id</span></p></td><td style="width:74.2pt; border-bottom-style:solid; border-bottom-width:4.5pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top; -aw-border-bottom:3pt thin-thick-small-gap"><p style="margin-bottom:0pt; font-size:11pt"><img src="images/Aspose.Words.05055d3e-3b48-405f-ac62-d07102973d18.002.jpeg" width="99" height="86" alt="" style="-aw-left-pos:0pt; -aw-rel-hpos:column; -aw-rel-vpos:paragraph; -aw-top-pos:0pt; -aw-wrap-type:inline" /></p></td></tr></table>
            <p><span style="-aw-import:ignore">&#xa0;</span></p>
            <table cellspacing="0" cellpadding="0" class="TableGrid" style="margin-bottom:0pt; border-collapse:collapse">
            <tr><td style="width:477.75pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top">
            <p style="margin-bottom:0pt; text-align:center; font-size:14pt"><span style="font-weight:bold">LAPORAN PERJALANAN DINAS</span></p></td>
        </tr><tr><td style="width:477.75pt; padding-right:5.4pt; padding-left:5.4pt; vertical-align:top"><p style="margin-bottom:0pt; text-align:center; font-size:11pt">
        <span style="font-weight:bold">Nomor SPPD :</span><span style="font-weight:bold">&#xa0;</span>
        <span style="font-weight:bold">&#xa0;</span><span style="font-weight:bold">&#xa0;</span><span style="font-weight:bold">&#xa0;</span><span style="font-weight:bold">&#xa0;</span><span style="font-weight:bold">&#xa0;</span><span style="font-weight:bold">&#xa0;</span><span style="font-weight:bold">&#xa0;</span><span style="font-weight:bold">&#xa0;</span><span style="font-weight:bold">-UPT.SMK.09/BLK/DISDIK</span></p></td></tr></table><p><span style="-aw-import:ignore">&#xa0;</span></p><table cellspacing="0" cellpadding="0" class="TableGrid" style="margin-bottom:0pt; border:0.75pt solid #000000; -aw-border:0.5pt single; -aw-border-insideh:0.5pt single #000000; -aw-border-insidev:0.5pt single #000000; border-collapse:collapse"><tr><td style="width:152pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-bottom:0.5pt single; -aw-border-right:0.5pt single"><p style="margin-bottom:0pt; line-height:200%">
        <span>NAMA</span></p></td><td style="width:314.95pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-bottom:0.5pt single; -aw-border-left:0.5pt single">
        <p style="margin-bottom:0pt; line-height:200%">
        <span>: <?php echo "{$nama}"?></span></p></td></tr><tr><td style="width:152pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-bottom:0.5pt single; -aw-border-right:0.5pt single; -aw-border-top:0.5pt single"><p style="margin-bottom:0pt; line-height:200%">
        <span>BERANGKAT</span></p></td><td style="width:314.95pt; border-top-style:solid; border-top-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-bottom:0.5pt single; -aw-border-left:0.5pt single; -aw-border-top:0.5pt single"><p style="margin-bottom:0pt; line-height:200%">
        <span>: <?php echo "$berangkat"?></span></p></td></tr><tr><td style="width:152pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-bottom:0.5pt single; -aw-border-right:0.5pt single; -aw-border-top:0.5pt single"><p style="margin-bottom:0pt; line-height:200%">
        <span>TUJUAN PERJALANAN DINAS</span></p></td><td style="width:314.95pt; border-top-style:solid; border-top-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-bottom:0.5pt single; -aw-border-left:0.5pt single; -aw-border-top:0.5pt single"><p style="margin-bottom:0pt; line-height:200%">
        <span>: <?php echo "$tujuan"?></span></p></td></tr><tr><td style="width:152pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-bottom:0.5pt single; -aw-border-right:0.5pt single; -aw-border-top:0.5pt single"><p style="margin-bottom:0pt; line-height:200%">
        <span>HASIL PERJALANAN DINAS</span></p></td><td style="width:314.95pt; border-top-style:solid; border-top-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-bottom:0.5pt single; -aw-border-left:0.5pt single; -aw-border-top:0.5pt single"><p style="margin-bottom:0pt; line-height:115%">
        <span>1. <?php echo "$hasil1"?></span></p><p style="margin-bottom:0pt; line-height:115%">
        <span>2. <?php echo "$hasil2"?></span></p><p style="margin-bottom:0pt; line-height:115%">
        <span>3. <?php echo "$hasil3"?></span></p><p style="margin-bottom:0pt; line-height:115%">
        <span>4. <?php echo "$hasil4"?></span></p></td></tr><tr><td style="width:152pt; border-top-style:solid; border-top-width:0.75pt; border-right-style:solid; border-right-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-bottom:0.5pt single; -aw-border-right:0.5pt single; -aw-border-top:0.5pt single"><p style="margin-bottom:0pt; line-height:200%">
        <span>KEMBALI TANGGAL</span></p></td><td style="width:314.95pt; border-top-style:solid; border-top-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; border-bottom-style:solid; border-bottom-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-bottom:0.5pt single; -aw-border-left:0.5pt single; -aw-border-top:0.5pt single"><p style="margin-bottom:0pt; line-height:200%">
        <span>: <?php echo "$tgl_kembali"?></span></p></td></tr><tr><td colspan="2" style="width:477.75pt; border-top-style:solid; border-top-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-top:0.5pt single"><p style="margin-bottom:0pt; text-align:center; font-size:11pt">
        <span style="font-weight:bold">FOTO-FOTO KEGIATAN PERJALANAN DINAS</span></p></td></tr></table><p><span style="-aw-import:ignore">&#xa0;</span></p>
        


        <table cellspacing="0" cellpadding="0" class="TableGrid" style="margin-bottom:0pt; border-collapse:collapse"><tr style="height:132.05pt">
        <td style="width:208.7pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border:0.5pt single">
        <p style="margin-bottom:0pt; font-size:11pt"><span style="-aw-import:ignore">FOTO 1</span></p>
        <img src="images/<?php echo $foto1; ?>" width="270" height="240"></td><td style="width:45.9pt; border-right-style:solid; border-right-width:0.75pt; border-left-style:solid; border-left-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border-left:0.5pt single; -aw-border-right:0.5pt single">
        <p style="margin-bottom:0pt; font-size:11pt"><span style="-aw-import:ignore">&#xa0;</span></p></td><td style="width:201.55pt; border-style:solid; border-width:0.75pt; padding-right:5.03pt; padding-left:5.03pt; vertical-align:top; -aw-border:0.5pt single">
        <p style="margin-bottom:0pt; font-size:11pt"><span style="-aw-import:ignore">FOTO 2</span></p>
        <img src="images/<?php echo $foto2; ?>" width="270" height="240">
    </td></tr>
    </table>
        
        <p><span style="-aw-import:ignore">&#xa0;</span></p></div>

        <script>
		window.print();
	</script>

    </body>
        </html>