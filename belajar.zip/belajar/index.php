<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Include file bootstrap.min.css -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Include library Font Awesome -->
    <link href="libraries/fontawesome/css/all.min.css" rel="stylesheet">

    <!-- Include library Datepicker Gijgo -->
    <link href="libraries/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet">
    <title>FORM LPD</title>
</head>
<body>
    <form action="lpd.php" method="post" enctype="multipart/form-data">
<div class="container">
<div class-"mb-3"><h2>BUAT LAPORAN HASIL PERJALANAN DINAS</h2></div>
<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Nama</label>
  <input type="input" class="form-control" name="nama" id="exampleFormControlInput1" placeholder="Ketikkan Nama" required>
</div> 

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Berangkat</label>
  <input type="input" class="form-control" name="berangkat" id="exampleFormControlInput1" placeholder="Tempat Berangkat" required>
</div> 

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Tujuan Perjalanan</label>
  <input type="input" class="form-control" name="tujuan" id="exampleFormControlInput1" placeholder="Tujuan Perjalanan Dinas" required>
</div> 

<div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Hasil Kegiatan</label>
  <input type="input" class="form-control" name="hasil1" id="exampleFormControlInput1" placeholder="1" required>
  <input type="input" class="form-control" name="hasil2" id="exampleFormControlInput1" placeholder="2">
  <input type="input" class="form-control" name="hasil3" id="exampleFormControlInput1" placeholder="3">
  <input type="input" class="form-control" name="hasil4" id="exampleFormControlInput1" placeholder="4">
</div>

<div class="mb-3">
<label for="exampleFormControlInput1" class="form-label">Tanggal Kembali</label>
                    <input type="text" id="datepicker" class="form-control datetimepicker-input" data-toggle="datetimepicker" data-target="#datepicker" autocomplete="off" name="tgl_kembali" />
                </div>


                <div class="mb-3">

  <label for="formFile" class="form-label">Upload Foto Kegiatan 1</label>
  <input class="form-control" type="file" name="foto1" id="formFile">
</div>
<div class="mb-3">

  <label for="formFile" class="form-label">Upload Foto Kegiatan 2</label>
  <input class="form-control" type="file" name="foto2" id="formFile">
</div>

<div class="col-12">
    <button class="btn btn-primary" name="cetak" type="submit">CETAK SURAT</button>
  </div>

</div>

</form>


 <!-- Include file jquery.min.js -->
 <script src="js/jquery.min.js"></script>

<!-- Include file boootstrap.min.js -->
<script src="js/bootstrap.min.js"></script>

<!-- Include library Moment JS -->
<script src="libraries/moment/moment.min.js"></script>

<!-- Include library Datepicker Gijgo -->
<script src="libraries/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

<!-- Include file custom.js -->
<script src="js/custom.js"></script>

<script>
$(document).ready(function(){
    setDatePicker("#datepicker")
    setDateRangePicker("#startdate", "#enddate")
    setMonthPicker("#monthpicker")
    setYearPicker("#yearpicker")
    setYearRangePicker("#startyear", "#endyear")
})
</script>
<script type="text/javascript">
 $(function(){
  $(".datepicker").datepicker({
      format: 'yyyy-mm-dd',
      autoclose: true,
      todayHighlight: true,
  });
 });
</script>
</body>
</html>